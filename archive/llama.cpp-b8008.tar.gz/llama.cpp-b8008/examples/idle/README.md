# llama.cpp/example/idle

https://github.com/ggml-org/llama.cpp/pull/17766
